package com.critique.focus

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        web = WebView(this)
        setContentView(web)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

/** Lets the web app schedule real phone notifications, even when the app is closed. */
class Bridge(private val c: Context) {
    private val am get() = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun pi(id: Int, title: String, text: String): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
            .putExtra("id", id).putExtra("title", title).putExtra("text", text)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    @JavascriptInterface
    fun schedule(id: Int, title: String, text: String, atMillis: Double) {
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis.toLong(), pi(id, title, text))
    }

    @JavascriptInterface
    fun cancel(id: Int) {
        am.cancel(pi(id, "", ""))
    }

    @JavascriptInterface
    fun getApps(): String {
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
            .filter { it.activityInfo.packageName != c.packageName }
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("n", it.first).put("p", it.second)) }
        return arr.toString()
    }

    private val prefs get() = c.getSharedPreferences("focus", Context.MODE_PRIVATE)

    @JavascriptInterface
    fun setBlocked(json: String) {
        val arr = JSONArray(json)
        val set = HashSet<String>()
        for (k in 0 until arr.length()) set.add(arr.getString(k))
        prefs.edit().putStringSet("blocked", set).apply()
    }

    @JavascriptInterface
    fun setFocus(untilMillis: Double) {
        prefs.edit().putLong("until", untilMillis.toLong()).apply()
    }

    @JavascriptInterface
    fun isBlockerOn(): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return s.contains(c.packageName + "/" + FocusService::class.java.name)
    }

    @JavascriptInterface
    fun openAccessibility() {
        c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
