package com.critique.focus

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/** During a focus session, sends you back to Critique when you open a blocked app. */
class FocusService : AccessibilityService() {
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val p = getSharedPreferences("focus", MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now >= p.getLong("until", 0L)) return
        val blocked = p.getStringSet("blocked", emptySet()) ?: emptySet()
        if (pkg !in blocked) return
        if (now - last < 1500) return
        last = now
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        )
        Toast.makeText(this, "Focus mode: stay on task!", Toast.LENGTH_SHORT).show()
    }

    override fun onInterrupt() {}
}
